import {applyTheme as _applyTheme} from './theme-training.generated.js';
export const applyTheme = _applyTheme;
