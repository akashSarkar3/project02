package com.vaadin.training.router.solution.step3;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.validator.EmailValidator;
import com.vaadin.flow.data.validator.StringLengthValidator;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

import java.io.Serial;

@Route(value = "Customer Form", layout = MyUI.class)


    public class CustomerForm extends VerticalLayout {

        @Serial
        private static final long serialVersionUID = 1L;

        private final Binder<Customer> binder;


    public CustomerForm() {
        this.binder = new Binder<>(Customer.class);

        TextField emailField = new TextField("Email");
        binder.forField(emailField)
                .withValidator(new EmailValidator("Invalid email address"))
                .bind(Customer::getEmail, Customer::setEmail);

        TextField idField = new TextField("ID");
        binder.forField(idField)
                .withValidator(new StringLengthValidator("ID must be between 5 and 10 characters", 5, 10))
                .bind(Customer::getId, Customer::setId);

        TextField firstNameField = new TextField("First Name");
        binder.forField(firstNameField).bind(Customer::getFirstName, Customer::setFirstName);

        TextField lastNameField = new TextField("Last Name");
        binder.forField(lastNameField).bind(Customer::getLastName, Customer::setLastName);

        ComboBox<String> statusComboBox = new ComboBox<>("Status");
        statusComboBox.setItems("ImportedLead", "NotContacted", "Contacted", "Customer", "ClosedLost");
        binder.forField(statusComboBox).bind(Customer::getStatus, Customer::setStatus);

        DatePicker birthDatePicker = new DatePicker("Birth Date");
        binder.forField(birthDatePicker).bind(Customer::getBirthDate, Customer::setBirthDate);

        FormLayout formLayout = new FormLayout();
        formLayout.add(firstNameField, lastNameField, idField, emailField, statusComboBox, birthDatePicker);

//      Button saveButton = new Button("Save", e -> {
//            if (binder.writeBeanIfValid(new Customer())) {
//                // Logic to save the data
//            }
//        });
//
//        Button cancelButton = new Button("Cancel", e -> {
//            // Logic to cancel
//        });
//
//        HorizontalLayout buttonsLayout = new HorizontalLayout(saveButton, cancelButton);


      //  add(formLayout, buttonsLayout);

        Button saveButton = new Button("Save");
        // Add a click listener to handle the save action
        saveButton.addClickListener(event -> {
            // Perform save action (e.g., saving data to a database or file)
            saveData();


            // Notify the user that data has been saved
            Notification.show("Data saved successfully!");
        });

        // Add the button to the layout


        add(formLayout);
        add(saveButton);
    }

    public void setCustomer(Customer customer) {
        binder.readBean(customer);
    }

    public void saveData() {
        Customer customer = binder.getBean();


        // Save the customer data
    }
}
