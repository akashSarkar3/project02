package com.vaadin.training.router.solution.step3;


import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Route(value = "Customer Data", layout = MyUI.class)
@RouteAlias(value = "", layout = MyUI.class)
@PageTitle("Home")
public class CustomerService extends VerticalLayout {

    private static final long serialVersionUID = 1L;
    private final Grid<Customer> grid;
    private final List<Customer> customers;

    public CustomerService() {
        // Initialize the customer list with some data
        this.customers = new ArrayList<>(List.of(
                new Customer("Ravi", "Kumar", "ravi.kumar@gmail.com", "16601", "NotContacted", LocalDate.now()),
                new Customer("Sai", "Reddy", "sai.reddy@gmail.com", "165402", "Contacted", LocalDate.now()),
                new Customer("Teja", "Rao", "teja.rao@gmail.com", "103568", "Contacted", LocalDate.now())
        ));

        this.grid = new Grid<>(Customer.class);
        grid.setItems(customers);
        grid.setColumns("firstName", "lastName", "email","id", "birthDate", "status");
        grid.getColumnByKey("id").setPartNameGenerator(person -> "font-weight-bold");
        grid.setSelectionMode(Grid.SelectionMode.MULTI);

        addEditColumn(grid);
        addDeleteColumn(grid);

        add(grid);
    }

    private void addEditColumn(Grid<Customer> grid) {
        grid.addComponentColumn(customer -> {
            Button editButton = new Button("Edit");
           editButton.setAutofocus(true);
           // editButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

            editButton.addClickListener(e -> openEditDialog(customer));
            return editButton;
        }).setHeader("Edit");
    }

    private void addDeleteColumn(Grid<Customer> grid) {
        grid.addComponentColumn(customer -> {
            Button deleteButton = new Button("Delete");
            deleteButton.addThemeVariants(ButtonVariant.LUMO_ERROR);
            deleteButton.addClickListener(e -> confirmDelete(customer));
            return deleteButton;
        }).setHeader("Delete");
    }

    private void openEditDialog(Customer customer) {
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("Edit Customer");

        TextField firstNameField = new TextField("First Name", customer.getFirstName(), "");
        TextField lastNameField = new TextField("Last Name", customer.getLastName(), "");
        TextField emailField = new TextField("Email", customer.getEmail(), "");
        TextField idField = new TextField("ID", customer.getId(), "");

        FormLayout formLayout = new FormLayout(firstNameField, lastNameField, emailField, idField);
        dialog.add(formLayout);

        Button saveButton = new Button("Save", e -> {
            customer.setFirstName(firstNameField.getValue());
            customer.setLastName(lastNameField.getValue());
            customer.setEmail(emailField.getValue());
            customer.setId(idField.getValue());

            save(customer); // Save changes to the list
            grid.setItems(customers); // Refresh the grid

            dialog.close();
            Notification.show("Customer details updated", 3000, Notification.Position.MIDDLE);
        });

        Button cancelButton = new Button("Cancel", e -> dialog.close());
        HorizontalLayout buttonsLayout = new HorizontalLayout(saveButton, cancelButton);

        dialog.getFooter().add(buttonsLayout);
        dialog.open();
    }

    private void confirmDelete(Customer customer) {
        ConfirmDialog dialog = new ConfirmDialog();
        dialog.setHeader("Delete Confirmation");
        dialog.setText("Are you sure you want to delete this customer?");
        dialog.setConfirmText("Delete");
        dialog.setCancelText("Cancel");

        dialog.addConfirmListener(event -> {
            delete(customer); // Delete from the list
            grid.setItems(customers); // Refresh grid with updated data
        });

        dialog.open();
    }

    private void save(Customer customer) {
        Optional<Customer> existingCustomer = customers.stream()
                .filter(c -> c.getId().equals(customer.getId()))
                .findFirst();

        if (existingCustomer.isPresent()) {
            customers.remove(existingCustomer.get());
        }
        customers.add(customer);
    }

    private void delete(Customer customer) {
        customers.remove(customer);
    }
}
