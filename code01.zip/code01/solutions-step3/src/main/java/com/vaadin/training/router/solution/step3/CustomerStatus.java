package com.vaadin.training.router.solution.step3;

public enum CustomerStatus {
    ImportedLead, NotContacted, Contacted, Customer, ClosedLost
}
